

addEventHandler("onClientPlayerHeliKilled",root,
function(attacker)
if attacker then
cancelEvent()
end
end)


