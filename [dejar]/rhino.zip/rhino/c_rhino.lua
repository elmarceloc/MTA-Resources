function handleVehicleDamage(attacker, weapon, loss, x, y, z, tire)
    if (weapon and getElementModel(source) == 432) then
        if weapon == 37 then
            cancelEvent()
        else
            setElementHealth(source,getElementHealth(source) - loss/8) 
        end
        outputChatBox(getElementHealth(source))
    end
end
addEventHandler("onClientVehicleDamage", root, handleVehicleDamage)