addEventHandler('onVehicleExplode',root,function()

    local id = getElementModel(source)	

    if id == 494 or id == 520 or id == 432 or id == 556 or id == 583 then
        destroyElement(source)
    end


end)