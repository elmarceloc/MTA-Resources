setWeaponProperty( 38, "poor", "damage", get('damage') )
setWeaponProperty( 38, "std", "damage", get('damage') )
setWeaponProperty( 38, "pro", "damage", get('damage') )