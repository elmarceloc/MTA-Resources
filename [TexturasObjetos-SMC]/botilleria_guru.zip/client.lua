txd = engineLoadTXD ( "12843.txd" )
engineImportTXD ( txd, 12843 )
dff = engineLoadDFF ( "12843.dff" )
engineReplaceModel ( dff, 12843 )

txd2 = engineLoadTXD ( "12845.txd" )
engineImportTXD ( txd2, 12845 )
dff2 = engineLoadDFF ( "12845.dff" )
engineReplaceModel ( dff2, 12845 )