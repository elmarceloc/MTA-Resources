panuelos = {}
parrillas = {}

sacos = {}
volantines = {} 

sacoId = 80
parrillaId = 902


function getPositionInfrontOfElement(element, meters)
    if (not element or not isElement(element)) then return false end
    local meters = (type(meters) == "number" and meters) or 3
    local posX, posY, posZ = getElementPosition(element)
    local _, _, rotation = getElementRotation(element)
    posX = posX - math.sin(math.rad(rotation)) * meters
    posY = posY + math.cos(math.rad(rotation)) * meters
    rot = rotation + math.cos(math.rad(rotation))
    return posX, posY, posZ , rot
end


addEventHandler('onResourceStart',root,function()

    setTimer(render,500,0)


    -- debug

   -- for i=0,60 do
   --     x = math.random(-100,100)
   --     y = math.random(-100,100)
  --      z = 20
        
  --      debug(createPed(40,x,y,z) )

  --  end

end)


addCommandHandler('pañuelo', function(thePlayer)
    
    local acc = getPlayerAccount(thePlayer)
    local panuelo = getAccountData(acc, 'panuelo')

    if panuelo ~= false then

        if isElement(panuelos[thePlayer]) then 
            destroyElement(panuelos[thePlayer])
            panuelos[thePlayer] = nil
            return
        end

        local x, y, z = getElementPosition (thePlayer)
        local obj = createObject(panuelo,x,y,z)
        panuelos[thePlayer] = obj
        setObjectScale(obj,0.4)
        exports.bone_attach:attachElementToBone(obj,thePlayer,12)    
        return
    end

    triggerClientEvent(thePlayer,'onFiestasPatriasNotificationColor',thePlayer,'Pañuelo','Debes comprar un pañuelo primero',{255,0,0})


end)

addCommandHandler('saco', function(thePlayer)

    local acc = getPlayerAccount(thePlayer)
    local saco = getAccountData(acc, 'saco')

    if saco ~= false then
        
        if sacos[thePlayer] then
            toggleControl(thePlayer, 'walk',true)
            toggleControl(thePlayer, 'sprint',true)
            toggleControl(thePlayer, 'forwards',true)
            sacos[thePlayer] = false

            local skin = getAccountData(acc,'prevSkin')
            setElementModel(thePlayer, skin)

        elseif not sacos[thePlayer] then
            toggleControl(thePlayer, 'walk',false)
            toggleControl(thePlayer, 'sprint',false)
            toggleControl(thePlayer, 'forwards',false)
            sacos[thePlayer] = true

            setAccountData(acc,'prevSkin',getElementModel(thePlayer))

            setElementModel(thePlayer, sacoId) -- saco
        end
        return
    end

    triggerClientEvent(thePlayer,'onFiestasPatriasNotificationColor',thePlayer,'Saco','Debes comprar un saco primero',{255,0,0})
end)

addCommandHandler('parrilla', function(thePlayer)
    local acc = getPlayerAccount(thePlayer)

    local asado = getAccountData(acc, 'asado')

    if asado ~= false then
        if isElement(parrillas[thePlayer]) then 
            destroyElement(parrillas[thePlayer])
            parrillas[thePlayer] = nil
            return
        end

        local x,y,z = getPositionInfrontOfElement(thePlayer,1.5)
        local parrilla = createObject(parrillaId,x, y, z-1)

        setElementCollisionsEnabled(parrilla, false)

        parrillas[thePlayer] = parrilla        
        
        triggerClientEvent(root,'smoke',root,parrilla)

        --setAccountData(acc,'asado', false)
        return
    end
    

    triggerClientEvent(thePlayer,'onFiestasPatriasNotificationColor',thePlayer,'Parrilla','Debes comprar la parrilla primero',{255,0,0})

end)


addCommandHandler('volantin', function(thePlayer)
    local acc = getPlayerAccount(thePlayer)

    local id = getAccountData(acc, 'volantin')

    if id ~= false then

        if getElementData(thePlayer,'volantin') then
            if isElement(volantines[thePlayer]) then destroyElement(volantines[thePlayer]) end
            volantines[thePlayer] = nil
            setElementData(thePlayer, 'volantin', false)

            toggleControl(thePlayer, 'next_weapon',true)
            toggleControl(thePlayer, 'previous_weapon',true)
            toggleControl(thePlayer, 'fire',true)

            triggerClientEvent (thePlayer, "carrete", getRootElement(),false ) 

        else
            
            local x,y,z = getElementPosition (thePlayer) --getPedBonePosition
            local lenght = math.random(9,16)
            
            -- setPedAnimation(thePlayer,'PED','idle_rocket',-1,true,false,true,false)
            
            local volantin = createObject(id,x+6,y+6,z+10)
               
            setElementRotation(volantin, 0,90,0)
            setObjectScale(volantin,2)
           
            volantines[thePlayer] = volantin

            setElementData(volantin, 'player', thePlayer)
            setElementData(volantin, 'volantin', true)

            setElementData(thePlayer, 'lenght', lenght)
            setElementData(thePlayer, 'volantin', true)
            --  setElementData(thePlayer, 'volantin', volantin)

            toggleControl(thePlayer, 'next_weapon',false)
            toggleControl(thePlayer, 'previous_weapon',false)
            toggleControl(thePlayer, 'fire',false)

            triggerClientEvent (thePlayer, "onVolantin", getRootElement(),true ) 

        end



        triggerClientEvent(thePlayer,'onFiestasPatriasNotification',thePlayer,'Volantin','Utiliza la rueda del mouse para ajustar\nel largo de tu volantín')
       -- triggerClientEvent(root,'onCreateVolantin',resourceRoot,thePlayer,volantin)

      
        return
    end

    triggerClientEvent(thePlayer,'onFiestasPatriasNotificationColor',thePlayer,'Volantin','Debes comprar un volantín primero',{255,0,0})
end)


color = tocolor(255,255,255,120)
speed = 0.1

function render()
    -- outputChatBox(#players)
     for player,volantin in pairs(volantines) do 
        local lenght =  getElementData(player,'lenght')
    
        local x,y,z = getElementPosition (player) --getPedBonePosition
      
        local xr,yr,zr = getElementRotation (player)
        local ox,oy,oz = getElementPosition(volantin)
        local fx,fy,fz = getPositionInfrontOfElement(player,(lenght / 2 ) + 8 )
    --    local vrx,vry,vrz = getElementRotation(volantin)
            

        -- esquina de ariba
        local nx = ox + ( fx - ox )*speed + math.sin( getTickCount ()/300 ) / 100
        local ny = oy + ( fy - oy )*speed + math.sin( getTickCount ()/400 ) / 100
        local nz = z + lenght + math.sin( getTickCount ()/1500 )
--]]

--   setElementPosition(volantines[player], nx, ny, nz)
        moveObject(volantin,500, nx, ny, nz)
        setElementRotation(volantin, xr,yr,zr-30)--zr-60 
        
     end
 end
 
 addEventHandler('onClientRender',root,render)



-- on discvonect

--dancing bd_clap1


function quitPlayer ( quitType )
    if isElement(parrillas[source]) then destroyElement(parrillas[source]) end
    if isElement(volantines[source]) then destroyElement(volantines[source]) end
    if isElement(panuelos[source]) then destroyElement(panuelos[source]) end
    

    volantines[source] = nil
    parrillas[source] = nil
    panuelos[source] = nil
end
addEventHandler ( "onPlayerQuit", root, quitPlayer )









function debug(thePlayer)

        local x,y,z = getElementPosition (thePlayer) --getPedBonePosition
        
        -- setPedAnimation(thePlayer,'PED','idle_rocket',-1,true,false,true,false)
        
        local volantin = createObject(1000,x+6,y+6,z+10)
        local lenght = math.random(9,16)


       -- attachElements(carrete,thePlayer,0.3)

        setElementRotation(volantin, 0,90,0)
        setObjectScale(volantin,2)
       -- setObjectBreakable(volantin, false)
    --  setElementDoubleSided(volantin,true)

       -- table.insert(players, thePlayer) 
       
        volantines[thePlayer] = volantin

        
        setElementData(volantin, 'volantin', true)
        setElementData(volantin, 'player', thePlayer)
        
        setElementData(thePlayer, 'lenght', lenght)
        setElementData(thePlayer, 'volantin', volantin)
end