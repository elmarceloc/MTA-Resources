shops = {
    {name = 'Fonda Tripulante', x = -120.00387, y =  -19.97614, z =  3.11719,    products = '1,11,8'},
    {name = 'Fondas QLS', x = -124.55011, y =  -31.32283, z =  3.11719,          products = '16,12,3'},
    {name = 'La Mortal Fondat', x = -125.82075, y =  -49.66383, z =  3.11719,    products = '12,3'},
    {name = 'Fonda Musical', x = -130.42192, y =  -55.12611, z =  3.11719,       products = '1'},
    {name = 'Terremotos que hablan', x = -88.73678, y =  -73.11385, z =  3.11719,products = '2,15'},
    {name = 'El déo de jarita', x = -97.44717, y =  -77.85683, z =  3.10940,     products = '1'},
    {name = 'La Michelhada fonda', x = -114.28022, y =  -95.22352, z =  3.11719,     products = '1,17'},
    {name = 'El sapo rico', x = -106.19428, y =  -97.93922, z =  3.11719,     products = '1'},
    {name = 'Churros', x = -98.19528, y =  -71.55376, z =  3.11719,     products = '1,17'},
    {name = 'Fondas que Hablan', x = -83.91705, y =  -55.54221, z =  3.11719,     products = '1,2,8,9'},
    {name = 'La fonda de papel',x = -79.47501, y =  -40.77223, z =  3.11719,     products = '2,15'},
    {name = '',x = -112.87357, y =  -63.71709, z =  3.11719,     products = '4,5,18,19,20,21'},
    {name = '',x = -108.33421, y =  -68.09287, z =  3.10940,     products = '22,23,24,25,26,27'},
    {name = '',x = -134.79117, y =  -46.29308, z =  3.11719,     products = '8'}, -- hotdog
    {name = 'Churros',x = -137.16887, y =  4.42417, z =  3.14123,     products = ''},
    {name = 'Tula',x = -141.91376, y =  -2.83901, z = 3.14204,     products = '4,5,18,19,20,21'}, -- tula
    {name = '',x = -148.66606, y =   10.15649, z = 3.15500,     products = '22,23,24,25,26,27'}, 
    {name = '',x = -148.92996, y =   0.68240, z = 3.15500,     products = '8,17'}, -- nodle exchange
    {name = '',x = -153.11423, y =   2.52915, z = 3.11719,     products = '8,17'},
    {name = '',x = -111.09190, y =   -80.88972, z = 3.11719,     products = '8'}, -- nodle exchange 2
    {name = '',x = -69.49271, y =   -40.70111, z = 3.11719,     products = '8,17'}, -- nodle exchange 2
}

addEventHandler('onResourceStart', getResourceRootElement(getThisResource()),function(res)
   

    for i,shop in ipairs(shops) do 
    

        local random =  {{18, 37, 98},{230, 0, 38}}

        color = random[math.random(#random)]


        local marker = createMarker(shop['x'], shop['y'], shop['z']-1, 'cylinder',1.2,color[1],color[2],color[3])

        shops[i]['marker'] = marker

    end

    addEventHandler('onMarkerHit',root,function(element)
        if getElementType(element) ~= 'player' then return end

        for key,shop in ipairs(shops) do 
            
            if source == shop['marker'] then
                triggerClientEvent(element, 'toggleShopPanel',root, shop['products'],shop['name'])
            end

        end

    end)



end)

function buy(player,shop,price,name,msj)
    if price > getPlayerMoney(source) then
        triggerClientEvent(source,'onFiestasPatriasNotificationColor',root,shop,'No te alcanza para comprar: '..name,{255,0,0})
        return false
    end

    takePlayerMoney(source, price)

    triggerClientEvent(source,'onFiestasPatriasNotificationColor',root,shop,'Compraste: '.. name..'\n'..msj ,'chile')

    return true
end


addEvent('onBuyFood',true)
addEventHandler('onBuyFood',root,
    function(shop,price,name,hp)
        local acc = getPlayerAccount(source)
        local amount = getAccountData(acc, 'food')

        if buy(source,shop,price,name,'Buen provecho!!') then
            local oldHp = getElementHealth(source)
            
            setElementHealth(source, oldHp + hp)

            anims = {'eat_burger','eat_chicken','eat_pizza'}
            
            if amount == false then
                amount = 0
            end

            if amount < 5 then
                amount = amount + 1
                setPedAnimation(source,'food',anims[math.random(#anims)],2000,false,false,true,false)
            else
                amount = 0
                setPedAnimation(source,'food','eat_vomit_p',2000,false,false,true,false)
                local oldHp = getElementHealth(source)

                setElementHealth(source, oldHp - 60)

                triggerClientEvent(source,'onFiestasPatriasNotificationColor',root,shop,'Conchetumare, comiste mucho!!' ,'chile')
            end

            if name == 'Empanada' then
                triggerClientEvent(source, 'onSpeed',source, 30, 0.5)
            elseif name == 'Choripan' then
                triggerClientEvent(source, 'onJump',source, 30, 0.001)
            elseif name == 'Asado + bebida' then
                setPedArmor(source,100)
            elseif name == 'Mote con huesillo XL' then
                setPedArmor(source,50)
            end
            setAccountData(acc, 'food',amount)
        end
    end
)


addEvent('onBuyAlchool',true)
addEventHandler('onBuyAlchool',root,
    function(shop,price,name,hp,duration,shake)

        if buy(source,shop,price,name,'Si bebe no condusca') then
            local oldHp = getElementHealth(source)
         
            local acc = getPlayerAccount(source)
            local amount = getAccountData(acc, 'alchool')

            if amount == false then
                amount = 0
            end

            if amount < 3 then
                if shake ~= 0 then amount = amount + 1 end
                setPedAnimation( source,"BAR", "dnk_stndF_loop", 5000, false, false, false, false )
                setElementHealth(source, oldHp + hp)
            elseif shake ~= 0 then
                amount = 0
                setPedAnimation(source,'food','eat_vomit_p',2000,false,false,true,false)
                local oldHp = getElementHealth(source)

                setElementHealth(source, oldHp - 60)

                triggerClientEvent(source,'onFiestasPatriasNotificationColor',root,shop,'Conchetumare, bebiste mucho!!' ,'chile')
            end

            setAccountData(acc, 'alchool',amount)


            setPedWalkingStyle ( source, 137 )

            triggerClientEvent(source, 'onDrunk', source,shake, duration)

            setTimer(function(player)
                setPedWalkingStyle ( player, 0 )
            end, duration * 1000, 1, source)
        end
    end
)

addEvent('onBuyVolantin',true)
addEventHandler('onBuyVolantin',root,
    function(shop,price,name,id)

        if buy(source,shop,price,name,'Usa /volantin para sacarlo.') then
            local acc = getPlayerAccount(source)
            setAccountData(acc, 'volantin',id)
        end


    end
)
addEvent('onBuySaco',true)
addEventHandler('onBuySaco',root,
    function(shop,price,name)
        
        if buy(source,shop,price,name,'Usa /saco para sacarlo.') then
            local acc = getPlayerAccount(source)
            setAccountData(acc, 'saco',true)

        end

    end
)
addEvent('onBuyPanuelo',true)
addEventHandler('onBuyPanuelo',root,
    function(shop,price,name,id)
        if buy(source,shop,price,name,'Usa /pañuelo para sacarlo.') then
            local acc = getPlayerAccount(source)
            setAccountData(acc, 'panuelo',id)

        end

    end
)

addEvent('onBuyParrilla',true)
addEventHandler('onBuyParrilla',root,
    function(shop,price,name,hp)
        if buy(source,shop,price,name,'Usa /parrilla para sacarla.') then
            local oldHp = getElementHealth(source)

            local acc = getPlayerAccount(source)
            setAccountData(acc, 'asado',true)

            setElementHealth(source, oldHp + hp)
        end

    end
)

addEvent('onBuySpeed',true)
addEventHandler('onBuySpeed',root,
    function(shop,price,name,duration,speed)
        if buy(source,shop,price,name,'Tines más velocidad durante: '..duration) then
          --[[  local acc = getPlayerAccount(source)

            setAccountData(acc,'prevSkin',getElementModel(source))
            setElementModel(source, 171)


            setTimer(function(acc,player)

                local skin = getAccountData(acc,'prevSkin')
                setElementModel(player, skin)
            end,duration*1000,1,acc,source)
            --]]
            triggerClientEvent(source, 'onSpeed',source, duration, speed)

        end

    end
)


addEvent('onBuyJump',true)
addEventHandler('onBuyJump',root,
    function(shop,price,name,duration,grav)
        if buy(source,shop,price,name,'Tines salto más alto durante: '..duration) then

            triggerClientEvent(source, 'onJump',source, duration, grav)

        end

    end
)