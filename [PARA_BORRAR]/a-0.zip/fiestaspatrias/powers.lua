function getPointFromDistanceRotation(x, y, dist, angle)

    local a = math.rad(90 - angle);
 
    local dx = math.cos(a) * dist;
    local dy = math.sin(a) * dist;
 
    return x+dx, y+dy;
 
end

function speedEffect()  
    if getControlState( "sprint" ) == true and getControlState("jump") == false and isElementWithinColShape(localPlayer,areaSpeed) == true then

        local x, y, z = getElementPosition(getLocalPlayer())
        local rx,ry,rz = getElementRotation(getLocalPlayer())

        local nx, ny = getPointFromDistanceRotation(x, y, speedPower, (rz)*-1)

        local clear = isLineOfSightClear( x, y, z, nx, ny, z, true, true, true, true, true, true, true)
        if clear == true  or speedPower > 5 then
            local lx, ly = getPointFromDistanceRotation(x, y, 1, (rz-8)*-1)
            local rx, ry = getPointFromDistanceRotation(x, y, 1, (rz+8)*-1)
            local clearl = isLineOfSightClear( x, y, z, lx, ly, z, true, true, true, true, true, true, true)
            local clearr = isLineOfSightClear( x, y, z, rx, ry, z, true, true, true, true, true, true, true)
            
            if clearl == true and clearr == true then

                local nz = getGroundPosition ( nx, ny, z+1 )
                if getDistanceBetweenPoints3D( x, y, z, nx, ny, nz) < 2 or speedPower >= 1.9 then
                    setElementPosition(localPlayer, nx, ny, nz+1, false)
                end
            end
        end

    end
end


function jump() 
    if not isPedInVehicle(getLocalPlayer()) and isElementWithinColShape(localPlayer,areaJump) then -- here you check if the player is not in a vehicle (in other words "on foot") 
     
        local moveState = getPedMoveState( getLocalPlayer() ) -- Get the player move state 
         
        if moveState == "jump" then 

            setGravity ( grav ) 
             
        elseif moveState ~= "jump" then 
         
            setGravity ( 0.008 ) 
         
        end 
    else
        setGravity ( 0.008 )  
    end
end 



addEvent('onSpeed',true)
addEventHandler('onSpeed',root,
function(time, newSpeed)
  --  setDevelopmentMode ( true ) 

    areaSpeed = createColCuboid(-500,-500,-100,1000,1000,300)

    speedPower = newSpeed

    addEventHandler('onClientRender',root,speedEffect)
    setTimer(function()
        removeEventHandler('onClientRender',root,speedEffect)
        destroyElement(areaSpeed)
    end,time*1000,1)
end
)


addEvent('onJump',true)
addEventHandler('onJump',root,
function(time, newGrav)
    
    --setDevelopmentMode ( true ) 

    areaJump = createColCuboid(-500,-500,-100,1000,1000,300)

    grav = newGrav

    addEventHandler('onClientRender',root,jump)
    setTimer(function()
        removeEventHandler('onClientRender',root,jump)
        setGravity ( 0.008 ) 
        destroyElement(areaJump)
    end,time*1000,1)
end
)

-- 
--           DEBUG
--     

--addEventHandler('onClientRender',root,speedEffect)
--addEventHandler("onClientRender", getRootElement(), jump)  

--
--
--
