players = {}
volantines = {}
carrete = nil
sacos = {}
lenghts = {}

showvolantines = true

idCarrete = 2670

function getPositionInfrontOfElement(element, meters)
    if (not element or not isElement(element)) then return false end
    local meters = (type(meters) == "number" and meters) or 3
    local posX, posY, posZ = getElementPosition(element)
    local _, _, rotation = getElementRotation(element)
    posX = posX - math.sin(math.rad(rotation)) * meters
    posY = posY + math.cos(math.rad(rotation)) * meters
    rot = rotation + math.cos(math.rad(rotation))
    return posX, posY, posZ , rot
end

function isElementWithinAColShape(element)
    if element or isElement(element)then
       for _,colshape in ipairs(getElementsByType("colshape"))do
      if isElementWithinColShape(element,colshape) then
         return colshape
      end
       end
    end
    outputDebugString("isElementWithinAColShape - Invalid arguments or element does not exist",1)
    return false
 end

function onVolantin (bool) 
    if bool then
        local x,y,z = getElementPosition(localPlayer)
        carrete = createObject(idCarrete,x,y,z-0.5)

        setObjectScale(carrete, 0.5)    

        addEventHandler("onClientKey", root, playerPressedKey)
    else
        if isElement(carrete) then destroyElement(carrete) end
        removeEventHandler("onClientKey", root, playerPressedKey)
    end
    
end 
addEvent( "onVolantin", true ) 
addEventHandler( "onVolantin", getRootElement(), onVolantin ) 




addCommandHandler('junaeb',function()
    showvolantines = not showvolantines
end)


speed = 0.02
color = tocolor(255,255,255,120)

function render()

    local lx,ly,lz = getPedBonePosition (localPlayer, 34)
    local xr,yr,zr = getElementRotation (localPlayer)

    if isElement(carrete) then setElementPosition(carrete, lx - math.sin(math.rad(zr - 30)) * 0.03 , ly+math.cos(math.rad(zr - 30)) * 0.03, lz-0.1) end
    
    if not showvolantines then return end
    
  
    for i, volantin in ipairs(getElementsByType("object")) do
        if getElementData(volantin,"volantin") then
            local player = getElementData(volantin,'player')
            
            local x,y,z = getPedBonePosition (player, 34)
            
            local dis = getDistanceBetweenPoints2D(lx,ly,x,y)
            
            if dis < 40  then

                local vx,vy,vz = getElementPosition(volantin)

                dxDrawLine3D(x , y, z, vx, vy, vz, color,0.6)
            end

        end

    end
        
end
addEventHandler('onClientRender',root,render)

      --[[  
            local lenght = getElementData(player,'lenght')
            
            local xr,yr,zr = getElementRotation (player)

            local ox,oy,oz = getElementPosition(volantin)
            local vrx,vry,vrz = getElementRotation(volantin)
                
            
            local fx,fy,fz = getPositionInfrontOfElement(player,(lenght / 2 ) + 8 )

            -- esquina de ariba
            local nx = ox + ( fx - ox )*speed --+ math.sin( getTickCount ()/300 ) / 100
            local ny = oy + ( fy - oy )*speed --+ math.sin( getTickCount ()/400 ) / 100
            local nz = z + lenght --+ math.sin( getTickCount ()/1500 ) + lenght 
            
            -- base de la cola
         --   local cx = nx - math.sin(math.rad(vrz- -45)) *(math.sqrt(2)-0.1)
          --  local cy = ny + math.cos(math.rad(vrz- -45)) *(math.sqrt(2)-0.1)
          --  local cz = nz

            -- base de la cuerda
            local vx = nx - math.sin(math.rad(vrz- -45)) *0.5
            local vy = ny + math.cos(math.rad(vrz- -45)) *0.5
            local vz = nz - 0.3
            
            -- cuerda 1
        --    local vx1 = nx - math.sin(math.rad(vrz- 0)) *0.5
         --   local vy1 = ny + math.cos(math.rad(vrz- 0)) *0.5
         --   local vz1 = nz
            
            -- cuerda 2
         --   local vx2 = nx - math.sin(math.rad(vrz+ 90)) *0.5
         --   local vy2 = ny + math.cos(math.rad(vrz+ 90)) *0.5
         --   local vz2 = nz

            -- cuerda principal
--]]


          --  dxDrawLine3D(x - math.sin(math.rad(zr - 30)) * 0.03 , y+math.cos(math.rad(zr - 30)) * 0.03, z-0.1, vx, vy, vz, color,0.6)
            
       --     local cause = ''

           -- local isHit,hx,hy,hz,elementHited = processLineOfSight(x - math.sin(math.rad(zr - 30)) * 0.03 , y+math.cos(math.rad(zr - 30)) * 0.03, z-0.1, vx, vy, vz, true,false,false,true,false,true,true)
            
          --  if not isHit then
              --  isHit,hx,hy,hz,elementHited = processLineOfSight(nx - math.sin(math.rad(vrz- -90)) *1, ny + math.cos(math.rad(vrz- -90)) *1,  nz, nx - math.sin(math.rad(vrz- -0)) *1, ny + math.cos(math.rad(vrz- -0)) *1,  nz, true,false,false,true,false,true,true)
                
              --  if not isHit then
              --      isHit,hx,hy,hz,elementHited = processLineOfSight(nx, ny,  nz, nx - math.sin(math.rad(vrz- -45)) *math.sqrt(2), ny + math.cos(math.rad(vrz- -45)) *math.sqrt(2),  nz, true,false,false,true,false,true,true)
              --  end
              --  cause = 'Tu volantín chocó :(\nCompra otro si quieres seguir weando con el volantín'
           -- else
            --    cause = 'Se cortó el hilo :(\nCompra otro si quieres seguir weando con el volantín'
           -- end

            --isHit = isHit and getElementModel(elementHited) ~= getElementData(player,'id') and getElementType(elementHited) ~= 'player' and getElementData(player, 'volantin')

         --[[   if false then

                triggerServerEvent('loseVolantin',root,'Volantín',cause,{255,0,0}, localPlayer)

                local dumie =  createVehicle(441,nx,ny,nz)
                attachElements(volantin,dumie)
                detachElements(volantin,dumie)

                destroyElement(carretes[player])

                setElementAlpha(dumie,0)
                setElementAlpha(carretes[player],0)
                setTimer(function()
                    destroyElement(dumie)
                end,200,1)

                setTimer(function()
                    destroyElement(volantin)
                    
                    volantin = nil
                end,4000,1)

                getElementCollisionsEnabled(volantin)
    

           --     toggleControl('next_weapon',true)
           --     toggleControl('previous_weapon',true)
           --     toggleControl('fire',true)

                setElementData(player, 'volantin', false)

            end
]]--
            -- cuerdas
         --   dxDrawLine3D(vx,vy,vz, vx1,vy1,vz1,color,1)
          --  dxDrawLine3D(vx,vy,vz, vx2,vy2,vz2,color,1)

            -- colas
         --   dxDrawLine3D(cx, cy, cz, cx+0.2+r, cy+0.2+r, cz-0.5, tocolor(145,33,30),2) -- roja
         --   dxDrawLine3D(cx, cy, cz, cx+0.8+r, cy+0.8+r, cz-0.5, tocolor(21,44,120),2) -- azul

       --     setElementPosition(carretes[player], x - math.sin(math.rad(zr - 30)) * 0.03 , y+math.cos(math.rad(zr - 30)) * 0.03, z-0.1)

       --     setElementPosition(volantines[player], nx, ny, nz)
       --     setElementRotation(volantines[player], xr,yr,zr-30)--zr-60



addEvent('onFiestasPatriasNotification',true)
addEventHandler('onFiestasPatriasNotification',root,function(title, text)
    if not getElementData(source,'volantin') then
        exports.notifications.createNotification(1,'',title,text,10000)
    end
end
)

addEvent('onFiestasPatriasNotificationColor',true)
addEventHandler('onFiestasPatriasNotificationColor',root,function(title, text, color)

    if color == 'chile' then
        local random =  {{18, 37, 98},{230, 0, 38}}

        color = random[math.random(#random)]

    end

    exports.notifications.createNotification(1,'',title,text,10000, color)
end
)



addEvent('smoke',true)
addEventHandler('smoke',root,function(element)
    local x,y,z = getElementPosition(element)
    local eff = createEffect("smoke30m", x, y+1, z)
    setTimer(function()
        if isElement(eff) then destroyElement(eff) end
    end,10000,1)
end)


function playerPressedKey(button, press)
    local lenght = getElementData(localPlayer, 'lenght')

    if (press and lenght ~= nil) then
        if button == 'mouse_wheel_up' and lenght < 50 then
            lenght = lenght *1.05
        elseif button == 'mouse_wheel_down' and lenght > 8 then
            lenght = lenght *1/1.05
        end
        
        setElementData(localPlayer,'lenght', lenght )        
    end
end