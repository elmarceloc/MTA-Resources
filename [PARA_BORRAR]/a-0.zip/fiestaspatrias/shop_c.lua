productsData = {

    -- {type = 'velocidad', name = 'Speed', price=1000, duration = 30, vel = 0.5 },
   --  {type = 'salto', name = 'jump', price=1000, duration = 30, newGrav = 0.001},
     {type = 'food', name = 'Empanada', price=1000, hp = 30},
     {type = 'alchool', name = 'Terremoto', price=1000, hp = -30, duration = 30,shake = 200},
     {type = 'parrilla', name = 'Parrilla', price=5000, hp = 100},
     {type = 'volantin', name = 'Volantin Bandera de Chile', price=600 , id=2880}, --3
     {type = 'volantin', name = 'Volantin de Felipito', price=2000, id=2953}, --1
     {type = 'saco', name = 'Saco', price=5000},
     {type = 'pañuelo', name = 'Pañuelo', price=5000, id = 1598},
     {type = 'food', name = 'Choripan', price=1000, hp = 10},
     {type = 'food', name = 'Mote con huesillo', price=800, hp = 50},
     {type = 'food', name = 'Mote con huesillo XL', price=2500, hp = 100},
     {type = 'food', name = 'Anticuchos', price=700, hp = 100},
     {type = 'food', name = 'Asado + bebida', price=10000, hp = 100},
     {type = 'food', name = 'Tortilla amasada', price=2000, hp = 50},
     {type = 'alchool', name = 'Cristal', price=700, hp = -10, duration = 10,shake = 120},
     {type = 'alchool', name = 'Terremoto para niños', price=1200, hp = 0, duration = 0,shake = 0},
     {type = 'alchool', name = 'Cerveza', price=1200, hp = -15, duration = 15,shake = 60},
     {type = 'alchool', name = 'Coca-Cola', price=700, hp = 15, duration = 0,shake = 0},
     
     {type = 'volantin', name = 'Volantin del Huachipato', price=10000, id=2703}, --2
     {type = 'volantin', name = 'Volantin Leo Rey', price=2000, id=3070}, -- 4
     {type = 'volantin', name = 'Volantin Diseño #2', price=2000, id=2768}, --5
     {type = 'volantin', name = 'Volantin Diseño #3', price=2000, id=2037}, --6
     {type = 'volantin', name = 'Volantin Diseño #4', price=2000, id=2881}, --7
     
     {type = 'volantin', name = 'Volantin Chayanne', price=50000, id=2702}, --8
     {type = 'volantin', name = 'Volantin Chupete Sueazo', price=2000, id=921}, --9
     {type = 'volantin', name = 'Volantin Mapuche', price=2000, id=1644}, --10
     {type = 'volantin', name = 'Volantin Miguelito', price=5000, id=2769}, --11
     {type = 'volantin', name = 'Volantin Neo cortex', price=2000, id=2709}, --12
 
 }
 
 
 npcs = {
     -- FONDA TRIPULANTE
     {id = 100, x = -116.70060, y =  -19.71740, z =  3.11719,rot = 70},
     {id = 100, x = -118.20985, y =  -22.37493, z =  3.11719,rot = 70},
     -- FONDAS QLS
     {id = 133, x = -121.44692, y =  -32.52256, z =  3.11719,rot = 70},
 
     -- Terremotos que hablan
     {id = 36, x = -88.39472, y =  -76.64171, z =  3.11719,rot = 30},
 
     --Fondas que Hablan
     {id = 36, x = -87.27898, y =  -54.40830, z =  3.11719,rot = 240},
     
     --La Michelhada fonda
     {id = 37, x = -117.47892, y =  -93.24806, z =  3.10940,rot = 240},
 
     {id = 120, x = -94.54315, y =  -79.77453, z =  3.11719,rot = 30},
     {id = 124, x = -97.29967, y =  -81.25519, z =  3.11719,rot = 30},
     {id = 217, x = -122.70970, y =  -48.52444, z =  3.11719,rot = 120},  ---- CAMBIAR A SKIN DE LEO REY
     {id = 217, x = -142.34535, y =  -6.52816, z =  3.11719,rot = 340},
     {id = 217, x = -144.91541, y =  -4.96075, z =  3.11719,rot = 340},
     {id = 155, x = -154.31587, y =  -0.24564, z =  3.11719,rot = 340}, -- puesto hotdog
     {id = 167, x = -136.24132, y =  6.47645, z =  3.11719,rot = 160},
     {id = 167, x = -147.68063, y =   11.99848, z =  3.34844,rot = 160}, 
     {id = 167, x = -150.13055, y =   -2.01247, z =  3.11719,rot = -20}, 
     {id = 167, x = -131.70898, y =   -58.27805, z =  3.11719,rot = 140+180}, 
     {id = 167, x = -133.58592, y =   -56.00732, z =  3.11719,rot = 140+180}, 
     {id = 167, x = -137.64105, y =   -46.25524, z = 3.11719,rot = 270}, 
     {id = 167, x = -114.37389, y =   -81.07339, z = 3.11719,rot = 270}, 
 
 }
 
 
 addEventHandler( "onClientResourceStart", getRootElement( ),
 function ( startedRes )
     for i,npc in ipairs(npcs) do 
 
         local ped = createPed ( npc['id'], npc['x'], npc['y'], npc['z'], npc['rot'] )
          
         function invPed()
             cancelEvent()
         end
         addEventHandler("onClientPedDamage",ped,invPed)
     end
 
 end
 );
 
 
 
 
 ------------------------
 -----Panel Ortalama-----
 ------------------------
 sC,sD = guiGetScreenSize()
 C,D = 430,400
 A = (sC/2) - (C/2)
 B = (sD/2.5) - (D/2)
 ---------------
 -----Panel-----
 ---------------
 panel = guiCreateStaticImage(A, B, C, D, "img/bg.png", false)
 guiSetVisible(panel,false)
 
 blue = guiCreateStaticImage(0, 0, C, 25, "img/r.png", false, panel)
 
 
 
 productsGui = {}
 productsLabels = {}
 
 ----------------------
 -----Panel close-----
 ----------------------
 close_label = guiCreateLabel(C-20, 5, 60, 24, "X", false, blue)
 guiSetFont(close_label, "default-bold-small")
 guiLabelSetColor(close_label, 255, 255, 255)
 
 function close()
 if source == close_label then
     guiSetVisible(panel, false)
     showCursor(false)
 end
 end
 addEventHandler("onClientGUIClick", root, close)
 
 
 
 
 buy_buton = guiCreateStaticImage(40, 190+ 160 , 354, 25, "img/b.png", false, panel)
 buy_label = guiCreateLabel(150, 5, 110, 25, "Comprar", false, buy_buton)
 guiSetFont(buy_label, "default-bold-small")
 guiLabelSetColor(buy_label, 255, 255, 255)
 
 
 ---------------------
 -----Buton Alpha-----
 ---------------------
 addEventHandler ("onClientMouseEnter", root,
 function ()
    if source == buy_label then
         guiSetAlpha(buy_label, 0.5)
    end
 end)
 
 addEventHandler ("onClientMouseLeave", root,
 function ()
    if source == buy_label then
         guiSetAlpha(buy_label, 1)
    end
 end)
 
 
 ----------------------
 -----Functions-----
 ----------------------
 
 selected = 99
 
 addEventHandler("onClientGUIClick",root,function()
 
 if source == buy_label then
 
     if selected == 99 then
         outputChatBox('Debes selecionar un producto para comprarlo',255,0,0)
         return
     end    
 
     for i,product in ipairs(productsData) do 
         if selected == i then
 
             if product['type'] == 'food' then
                 triggerServerEvent ("onBuyFood", localPlayer, shop ,product['price'],product['name'],product['hp'])
             elseif product['type'] == 'alchool' then
                 triggerServerEvent ("onBuyAlchool", localPlayer, shop ,product['price'],product['name'],product['hp'],product['duration'],product['shake'])
             elseif product['type'] == 'volantin' then
                 triggerServerEvent ("onBuyVolantin", localPlayer, shop ,product['price'],product['name'],product['id'])
             elseif product['type'] == 'saco' then
                 triggerServerEvent ("onBuySaco", localPlayer, shop ,product['price'],product['name'])
             elseif product['type'] == 'pañuelo' then
                 triggerServerEvent ("onBuyPanuelo", localPlayer, shop ,product['price'],product['name'],product['id'])
             elseif product['type'] == 'velocidad' then
                 triggerServerEvent ("onBuySpeed", localPlayer, shop ,product['price'],product['name'],product['duration'],product['vel'])
             elseif product['type'] == 'salto' then
                 triggerServerEvent ("onBuyJump", localPlayer, shop ,product['price'],product['name'],product['duration'],product['newGrav'])
             elseif product['type'] == 'parrilla' then 
                 triggerServerEvent ("onBuyParrilla", localPlayer, shop ,product['price'],product['name'],product['hp'])
             end
 
         end
     end
 
     hideShopPanel()
 end
 
 for id,product in pairs(productsGui) do 
 
     guiSetAlpha(productsGui[id],0.5)
 
     if source == product then
         selected = id
 
         guiSetAlpha(productsGui[selected],1)
     end
 
 end
 
 
 
 end)
 
 
 size = 100
 
 
 function shopPanel(products, shopName)
 
     selected = 99
     productsTable = split(products,',')
 
     shop = ''
 
     if shopName == '' then shopName = '             Local' end
 
     shop = shopName
 
     for key,gui in pairs(productsGui) do 
         guiSetVisible(gui,false)
         productsGui[key] = nil
     end
 
 
 
     for i,product in ipairs(productsTable) do 
 
         local id = tonumber(product)
 
 
         -- TODO: crear label
 
         local offsetY = 0
         local offsetX = 0
 
         if i > 3 then
             offsetY = size + 60
             offsetX = - size * 3 - 3*25
         end
 
         local title = guiCreateLabel(160,5,200,40,shopName,false,panel)
         guiSetFont(title, "default-bold-small")
 
         productsGui[id] = guiCreateStaticImage(40 + size * (i-1) + 25*(i-1) + offsetX,60+offsetY,size,size,'products/'..product..'.png',false,panel)
 
         guiSetAlpha(productsGui[id],0.5)
     end
 
     guiSetVisible(panel, true)
     showCursor(true)
 end
 addEvent( "toggleShopPanel", true )
 addEventHandler( "toggleShopPanel", getRootElement(), shopPanel)
 
 function hideShopPanel()
 guiSetVisible(panel, false)
 showCursor(false)
 end
 
 
 
 
 function drunk(shake, duration)
 setCameraShakeLevel(shake)
 
 setTimer(function()
     setCameraShakeLevel(0)
 end, duration * 1000, 1)
 end
 addEvent( "onDrunk", true )
 addEventHandler( "onDrunk", getRootElement(), drunk)