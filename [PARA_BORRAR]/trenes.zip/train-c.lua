--****************************************************************************************************
--[[ 
	Resource:		AC Train system (ac-train)
	Filename:		train-c.lua
	Developers:		Albonius corporation (MrBrutus, VPK4)
	Copyrights:		Albonius corporation 2011 - 2014 (Sweden)
	
	Support url:	
	Bug reports:	
	Installation:	http://games.albonius.com
	ACRP Version:	2.0.0
	
	Script type: 	Client
	Description:	Prevent trains from stream out
	Status:			Active
]]--
--****************************************************************************************************

-- Allow the train to move when no player can see it
function stream ( veh )
	setElementStreamable( veh, true )
end
addEvent( "train.onstream", true )
addEventHandler( "train.onstream", getRootElement(), stream )

addEventHandler( "onClientElementStreamOut", getRootElement( ),
    function ( )
        if getElementType( source ) == "vehicle" and getVehicleType(source) == "Train" then
            triggerServerEvent( "train_onClientStreamOut", localPlayer, getElementData( source, "syncer" ))           
        end
    end
);
