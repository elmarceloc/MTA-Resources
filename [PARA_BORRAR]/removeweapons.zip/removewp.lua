
 function removeweapons ( thePlayer )
    takeAllWeapons ( thePlayer )
 end

 addCommandHandler ( "rwp", removeweapons )
 
 --#Nahuel 2018 © Copyright. All rights reserved