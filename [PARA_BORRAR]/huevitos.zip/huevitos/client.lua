
txd_huevito1 = engineLoadTXD ( "img/huevo.txd" )
engineImportTXD ( txd_huevito1, 1247 )
dff_huevito1 = engineLoadDFF ( "img/huevo.dff" )
engineReplaceModel ( dff_huevito1, 1247 )
