local zona = createColCuboid ( 2219.67944, 2391.71411, -40, 150.0, 130.0, 5.0 )

function hill_Enter ( thePlayer, matchingDimension )
        if getElementType ( thePlayer ) == "player" then
                --killPed( thePlayer )
                setElementPosition( thePlayer, 2366.19507, 2418.35376, 86.53568 )
        end
end
addEventHandler ( "onColShapeHit", zona, hill_Enter )