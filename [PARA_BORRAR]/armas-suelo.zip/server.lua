function createGroundWeapon(weaponid, ammo, clip, posX, posY, posZ, rotX, rotY, rotZ, interior, dimension)
	local temp = createElement("groundweapon")
	setElementData(temp, "weaponid", weaponid)
	setElementData(temp, "ammo", ammo)
	setElementData(temp, "clip", clip)
	setElementData(temp, "posX", posX)
	setElementData(temp, "posY", posY)
	setElementData(temp, "posZ", posZ)
	setElementData(temp, "rotX", rotX)
	setElementData(temp, "rotY", rotY)
	setElementData(temp, "rotZ", rotZ)
	setElementData(temp, "interior", interior)
	setElementData(temp, "dimension", dimension)
	for i,p in ipairs(getElementsByType("player")) do
		callClientFunction(p, "client_createGroundWeapon", temp)
	end
	return temp
end

addEventHandler("onResourceStop", getResourceRootElement(),
	function(startedRes)
		if(startedRes == getThisResource()) then
			for i,p in pairs(getElementsByType("groundweapon")) do
				destroyElement(p)
			end
		end
	end
)

function callServerFunction(funcname, ...)
    local arg = { ... }
    if (arg[1]) then
        for key, value in next, arg do arg[key] = tonumber(value) or value end
    end
    loadstring("return "..funcname)()(unpack(arg))
end
addEvent("onClientCallsServerFunction", true)
addEventHandler("onClientCallsServerFunction", resourceRoot , callServerFunction)

function callClientFunction(client, funcname, ...)
    local arg = { ... }
    if (arg[1]) then
        for key, value in next, arg do
            if (type(value) == "number") then arg[key] = tostring(value) end
        end
    end
    triggerClientEvent(client, "onServerCallsClientFunction", resourceRoot, funcname, unpack(arg or {}))
end