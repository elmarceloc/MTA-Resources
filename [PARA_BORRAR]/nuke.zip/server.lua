local nukeExists=false
local preventNukers={}
			
addEventHandler("onVehicleExplode",getRootElement(),function()
	if getElementModel(source)==594 then
		destroyElement(source)
	end
end)

function isPedDrivingVehicle(ped) --https://wiki.multitheftauto.com/wiki/IsPedDrivingVehicle
    assert(isElement(ped) and (getElementType(ped) == "ped" or getElementType(ped) == "player"), "Bad argument @ isPedDrivingVehicle [ped/player expected, got " .. tostring(ped) .. "]")
    local isDriving = isPedInVehicle(ped) and getVehicleOccupant(getPedOccupiedVehicle(ped)) == ped
    return isDriving, isDriving and getPedOccupiedVehicle(ped) or nil
end

function removePlayerTimerStart(a,b)
	local serial=getPlayerSerial(a)
	preventNukers[serial]=setTimer(function()							
		preventNukers[serial]=nil	
	end, 1000*60*b,1)
end

function spawnNuke(player, a, b)
	local valid=false
	local onlyAircraft=false	
	if get("onlyAircraft") then 	
		onlyAircraft=get("onlyAircraft")
		if onlyAircraft=="true" then 
			onlyAircraft=true 
		else
			onlyAircraft=false
		end
	end
	if onlyAircraft then 
		local drivingCheck, vehicleCheck = isPedDrivingVehicle ( player )
		local validVehicles={592,577,511,512,593,520,553,476,519,460,513,548,425,417,487,488,497,563,447,469} --aircraft, you can add vehicle ID's here to disable, provided onlyAircraft setting is true in meta.xml		
		if drivingCheck and vehicleCheck then 
			for i,v in ipairs(validVehicles) do
				if getElementModel(vehicleCheck) == v then 
					valid=true
					break
				end
			end
		end
	end
	if valid or not onlyAircraft then
		local preventMinutes=1
		if get("waitingMinutesBeforeAnotherNuke") then preventMinutes=tonumber(get("waitingMinutesBeforeAnotherNuke")) end
		if preventMinutes>0 then 
			local msg=nil
			if preventMinutes==1 then msg="minute" else msg="minutes" end
			for i,v in pairs(preventNukers) do
				if getPlayerSerial(player)==i then 					
					outputChatBox("You need to wait ".. preventMinutes .." " .. msg .. " before spawning another nuke!",player,255,0,0) 
					return 
				end		
			end	
		end
		local multiNukesAllowed=false
		if get("multipleNukesAllowed") then 
			multiNukesAllowed=get("multipleNukesAllowed") 
			if string.lower(multiNukesAllowed)=="true" then 
				multiNukesAllowed=true 
			elseif string.lower(multiNukesAllowed)=="false" then
				multiNukesAllowed=false 
			end
		end
		if not nukeExists or multiNukesAllowed then 
			if b then		
				local cost=50000
				if get("costOfNuke") then cost=tonumber(get("costOfNuke")) end
				local buck=getPlayerMoney(player)
				px,py,pz=getElementPosition(player)			
				local noOfPots=100
				if get("noOfExplosions") then noOfPots=tonumber(get("noOfExplosions")) end
				if noOfPots<=0 then noOfPots=1 end
				if b=="ground" then 			
					b=math.sqrt(2*pz/9.8)+(0.01*noOfPots)+(0.01*pz)
				elseif tonumber(b)==nil then 
					outputChatBox("Syntax is /nuke no_of_seconds_before_explosion",player,255,0,0)
					return
				elseif tonumber(b)<=0 then
					b=1
				end			
				
				minimumb=1
				if get("minDetonationTime") then minimumb=tonumber(get("minDetonationTime")) end
				if minimumb<=0 then minimumb=1 end			
				if tonumber(b)<minimumb then b=minimumb end
				
				maximumb=25
				if get("maxDetonationTime") then maximumb=tonumber(get("maxDetonationTime")) end
				if maximumb>0 then 
					if tonumber(b)>maximumb then b=maximumb end
				end			
				
				if not(b==b) then b=5 end
				local noOfSecondsBeforeCleanUp=20
				if get("secondsBeforeCleanUp") then noOfSecondsBeforeCleanUp=tonumber(get("secondsBeforeCleanUp")) end
				if noOfSecondsBeforeCleanUp<=0 then noOfSecondsBeforeCleanUp=5 end
				if buck >= cost then
					if preventMinutes>0 then 
						removePlayerTimerStart(player,preventMinutes)
					end
					nukeExists=true			
					setPlayerMoney(player,buck-cost)				
					px=px+3
					pz=pz+1
					local modelBomb=createObject(1636,px,py,pz,-90)
					markerEnabled=0
					if get("markerEnabled") then 				
						markerEnabled=tonumber(get("markerEnabled"))
						if markerEnabled==1 then 
							markerEnabled=true
						else					
							markerEnabled=false 
						end
					else
						markerEnabled=false
					end								
					local radius=30.0
					if get("clearRadius") then 
						radius=tonumber(get("clearRadius")) 
					end
					if radius>0 then 
						sphere=createColSphere(px,py,pz,radius)	
						setElementData(sphere,"creator",player)						
						vehicles=getElementsWithinColShape(sphere,"vehicle")
					end
					if markerEnabled and not multiNukesAllowed then 
						checkpoint=createMarker(px,py,pz,"checkpoint",4,255,0,0,255,getRootElement())	
					end
					local modelScale=10
					if get("sizeOfBombModel") then modelScale=tonumber(get("sizeOfBombModel")) end
					if modelScale<=0 then modelScale=1 end
					setObjectScale(modelBomb,modelScale)				
					local x				
					for var=1,noOfPots,1 do 
						x=createVehicle(594,px,py,pz) 
						setElementData(x,"creator",player)
						setElementAlpha(x,0)
						setVehicleHandling(x,"mass",1.0)
						setElementVelocity(x,0,0,-0.1)
						setElementHealth(x,getElementHealth(x)/3)
					end	
					attachElements(modelBomb,x,0,0,0,-90)
					setTimer (function() 					
						destroyElement(modelBomb) 
						setElementHealth(x,0) 
						if (vehicles) then 
							for i,v in pairs(vehicles) do 
								if v then setElementHealth(v,getElementHealth(v)/10) end
							end 
						end
						setTimer(function()
							nukeExists=false
							modelBomb=nil
							if checkpoint then destroyElement(checkpoint) end
						end, tonumber(noOfSecondsBeforeCleanUp*1000),1)
					end, tonumber(b)*1000, 1)
					outputChatBox("Your nuke will explode in "..b.. " seconds!", player, 255,255,0)
					outputChatBox("Beware! #FFFFFF"..getPlayerName(player).. " #FFFF00has spawned a nuke!" , getRootElement(), 255,255,0,true)
				else
					outputChatBox("You need $"..cost.." to spawn a nuke.",player,255,0,0)
				end
			else 
				outputChatBox("Syntax is /nuke no_of_seconds_before_explosion",player,255,0,0)
			end
		else 
			outputChatBox("A nuke is already spawned! Try later.",player,255,0,0)
		end
	else 
		outputChatBox("You have to be in an aircraft!",player,255,0,0,false)
	end
end	
addCommandHandler("nuke",spawnNuke)

addEventHandler("onPlayerQuit", getRootElement(), function()
	for i,v in pairs(getElementsByType("vehicle")) do
		if getElementModel(v)==594 and getElementData(v,"creator")==source then 
			destroyElement(v)
		end
	end
	for i,v in pairs(getElementsByType("colshape")) do
		if getElementData(v,"creator")==source then 
			destroyElement(v)
		end
	end
end)