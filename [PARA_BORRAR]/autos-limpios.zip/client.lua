-- Please, Don't remove credits..)
myShader = dxCreateShader( "texture.fx" )
addEventHandler( "onClientResourceStart", resourceRoot,
function()
    engineApplyShaderToWorldTexture( myShader, "vehiclegrunge256", theVehicle )
    engineApplyShaderToWorldTexture( myShader, "?emap*", theVehicle )
end
)
-- Start of a Credits to FornetGear
function advice ( )
	local resName = getResourceName( )
	outputChatBox ( "" .. resName .. " was made by FornetGear!" , source, 255, 255, 0 )
	outputChatBox ( "" .. resName .. " был сделан FornetGear'ом!" , source, 255, 255, 0 )
end
addEventHandler ( "onPlayerJoin", getRootElement(), advice )
-- End of a Credits to FornetGear