-- how much time(minutes) before kick the player
local KICK_TIME	= 5
-- timer interval in secondes
local TIMER_INTERVAL = 60

function kick_afk()
	for index, player in ipairs(getElementsByType("player")) do
		if( getPlayerIdleTime(player) > KICK_TIME * 1000 * 60 ) then
			kickPlayer(player, "server", "fuiste expulsado por estar afk más de " .. KICK_TIME .. " minutos")
		end
	end
end
setTimer(kick_afk, 1000 * TIMER_INTERVAL * 10, 0) 