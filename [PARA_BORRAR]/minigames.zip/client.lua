function minigamenotification(title,mensaje)
    exports.notifications:createNotification(1,title,mensaje,5000,{255,0,0})

end
addEvent( "minigamenotification", true )
addEventHandler( "minigamenotification", getRootElement(), minigamenotification)


function soundtrack(file)
    soundtrackElement = playSound(file,true)
    setSoundVolume(soundtrackElement,0.2)
end
addEvent( "soundtrack", true )
addEventHandler( "soundtrack", getRootElement(), soundtrack)



function muteSoundtrack()
    stopSound(soundtrackElement)
end
addEvent( "muteSoundtrack", true )
addEventHandler( "muteSoundtrack", getRootElement(), muteSoundtrack)



