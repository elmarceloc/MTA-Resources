function check(player) 
    if isObjectInACLGroup ( "user." .. getAccountName ( getPlayerAccount ( player ) ), aclGetGroup ( "Admin" ) ) or isObjectInACLGroup ( "user." .. getAccountName ( getPlayerAccount ( player ) ), aclGetGroup ( "Moderator" ) ) then 
        return true 
    end 
    return false 
end 

remainingPlayers = 0

addCommandHandler('br',function(admin, commandname)
    if check(admin) then
        local top_20 = false
        local top_10 = false
        local top_5 = false
        local win = false

        local x, y, z = getElementPosition(admin) 
        local colshape = createColSphere(tonumber(x), tonumber(y), tonumber(z), tonumber(30)) 
        
        for index, player in ipairs(getElementsWithinColShape(colshape, 'player')) do 
            setElementDimension(player,2)
            setElementHealth(player,100)
            setElementPosition(player,-2322.21606, -1621.69238, 483.71014)
            giveWeapon(player,46,1)
            giveWeapon(player,30,20)
            giveWeapon(player,25,30)
        
            setPedArmor(player,100)
            setElementData(player,'br','on')

        end 

        local vehicle = createVehicle(553,-2311.67432, -1648.91785, 483.70313, 0,0,260)
        setElementDimension(vehicle,2)
        warpPedIntoVehicle(admin, vehicle)

        battleroyale = setTimer(function()
            local players = 0

            for k, player in ipairs(getElementsByType("player")) do

                if getElementDimension(player) == 2 and check(player) == false then

                    players = players + 1

                end

            end 

            remainingPlayers = players

            if players == 20 and not top_20 then 
                for k, player in ipairs(getElementsByType("player")) do
                    if getElementDimension(player) == 2 then
                        triggerClientEvent(player,'minigamenotification',root,'Battle Royale', 'Quedan menos de 20 jugadores vivos!')
                        top_20 = true
                    end
                end 
            end

            if players == 10 and not top_10 then 
                for k, player in ipairs(getElementsByType("player")) do
                    if getElementDimension(player) == 2 then
                        triggerClientEvent(player,'minigamenotification',root,'Battle Royale', 'Quedan menos de 10 jugadores vivos!')
                        top_10 = true
                    end
                end 
            end

            if players == 5 and not top_5 then 
                for k, player in ipairs(getElementsByType("player")) do
                    if getElementDimension(player) == 2 then
                        triggerClientEvent(player,'minigamenotification',root,'Battle Royale', 'Quedan menos de 5 jugadores vivos!')
                        top_5 = true
                    end
                end 
            end

            if players == 1 and not win then 
                for k, player in ipairs(getElementsByType("player")) do
                    if getElementDimension(player) == 2 and check(player) == false then
                        win = true
                        triggerClientEvent(player,'minigamenotification',root,'Ganaste!')
                        givePlayerMoney(player,65000)
                        setTimer(function()
                            if isTimer(battleroyale) then killTimer(battleroyale) end
                            setElementDimension(player,0)
                            setElementData(player,'br','off')
                        end,5000,1)
                    end
                end 
            end
                        
        end,500,0)


    end
end)

addCommandHandler('salirbr',function(admin)
    if check(admin) then
        
        if isTimer(battleroyale) then killTimer(battleroyale) end
        for k, player in ipairs(getElementsByType("player")) do
            if getElementDimension(player) == 2 then
                setElementDimension(player,0)
                setElementData(player,'br','off')
            end
        end 
    end
end)

addEventHandler('onPlayerWasted',root,function(ammo, attacker, weapon, bodypart)
    if getElementDimension(source) == 2 and not check(source) then

        setElementDimension(source,0)
        setElementData(source,'br','off')

        triggerClientEvent(source,'minigamenotification',root,'Battle Royale', 'Quedaste '.. remainingPlayers ..'!')

        if remainingPlayers == 1 then
            givePlayerMoney(source,65000)
            return
        end

        if remainingPlayers == 2 then
            givePlayerMoney(source,30000)
            return
        end

    end

end)