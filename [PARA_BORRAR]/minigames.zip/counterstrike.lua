function check(player) 
    if isObjectInACLGroup ( "user." .. getAccountName ( getPlayerAccount ( player ) ), aclGetGroup ( "Admin" ) ) or isObjectInACLGroup ( "user." .. getAccountName ( getPlayerAccount ( player ) ), aclGetGroup ( "Moderator" ) ) then 
        return true 
    end 
    return false 
end 


function spawn(player,team)
    local x,y,z,skin,msg
    local rx = math.random(-3,3)
    local ry = math.random(-3,3)

    if team then -- terrorist
        x = 684.62970
        y = -2748.88232
        z = 204.44615

        skin = {287, 241, 179}

        msg = 'Eres parte de los terroristas'

    else -- counter
        x = 711.78021
        y = -2661.63232
        z = 197.55385
        skin = {105, 106, 107}
        msg = 'Eres parte de las Fuerzas Especiales'
    end

    giveWeapon(player,31,300)
    giveWeapon(player,27,300)
    giveWeapon(player,34,300)
    giveWeapon(player,28,300)

    setElementModel(player, skin[ math.random( #skin ) ]) 

    setElementDimension(player,12)
    setElementHealth(player,100)
    setElementPosition(player, x+rx,y+ry, z)

    setElementFrozen(player,true)

    setElementData(player,'cs','on')

    triggerClientEvent(player,'minigamenotification',root,'Counter strike 1.6', msg)

    triggerClientEvent(player,'soundtrack',root,'cs.wav')

    setTimer(function()
        setElementFrozen(player,false)
    end,6000,1)


end

addCommandHandler('cs',function(admin, commandname, terrorisTeamName, counterTeamName)
    if check(admin) then
        
        local terroristTeam = getTeamFromName(terrorisTeamName)
        local counterTeam = getTeamFromName(counterTeamName)

        if not terroristTeam then
            outputChatBox('Primer equipo no existe o esta mal escrito',admin,255,0,0)
            return
        end

        if not counterTeam then
            outputChatBox('Segundo equipo no existe o esta mal escrito',admin,255,0,0)
            return
        end

        setElementPosition(admin, 698.57806, -2686.32617, 228.78302)
        setElementDimension(admin, 12)
        setPedWearingJetpack(admin,true)
        triggerClientEvent(admin,'soundtrack',root,'cs.wav')


        for index, terrorist in ipairs(getPlayersInTeam(terroristTeam)) do 
            spawn(terrorist, true)
        end 

        for index, counter in ipairs(getPlayersInTeam(counterTeam)) do 
            spawn(counter, false)
        end 

    end
end)

addCommandHandler('salircs',function(admin)
    if check(admin) then
        for k, player in ipairs(getElementsByType("player")) do
            if getElementDimension(player) == 12 then
                setElementDimension(player,0)
                setElementData(player,'cs','off')
                setElementHealth(player,0)
                triggerClientEvent(player,'muteSoundtrack',root)
            end
        end 
    end
end)

addEventHandler('onPlayerWasted',root,function(ammo, attacker, weapon, bodypart)
    if getElementDimension(source) == 12 then
        triggerClientEvent(source,'muteSoundtrack',root)
        setElementDimension(source,0)
        setElementData(source,'cs','off')
        
        if not attacker then return end

        local asesino = getPlayerName(attacker)


        triggerClientEvent(source,'minigamenotification',root,'Counter strike 1.6', asesino.. ' te mató!')

        
    end

end)