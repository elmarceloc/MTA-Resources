sw, sh = guiGetScreenSize ( )
mouse1Pressed = false
boolFPS = false
zeroInitialPosition = createObject( 2320, 100, 100, 10 )
crossDraw = false
setElementAlpha( zeroInitialPosition, 0 )
setElementCollisionsEnabled( zeroInitialPosition, false )
attachElements( zeroInitialPosition, localPlayer, 0, -0.3, 0.65 )
--Function made by 'Doomed_Space_Marine', and fixed by 'robhol'
function findRotation( x1, y1, x2, y2 ) 
    local t = -math.deg( math.atan2( x2 - x1, y2 - y1 ) )
    return t < 0 and t + 360 or t
end
setTimer( function() vehicleVar = getPedOccupiedVehicle( localPlayer ) end, 1, 0 )
setTimer( function()
    pedPos = getPedBonePosition( localPlayer, 6 )
    vehiclePos = getElementPosition( vehicleVar )
    --outputChatBox( pedPos, 144, 144, 0 )
    --outputChatBox( vehiclePos, 144, 0, 144 )
end, 1000, 0 )
function getComparedPositions()
    updtPos = pedPos - vehiclePos
    --outputChatBox( updtPos, 0, 144, 144 )
end
addEventHandler( "onClientVehicleEnter", root, getComparedPositions )
function cameraFPS()
    if boolFPS then
        setElementAlpha ( localPlayer, 0 )
        local x1, y1, z1 = getElementPosition( zeroInitialPosition )
        setCameraMatrix ( x1, y1, z1 )
        if isPedInVehicle( localPlayer ) then
            detachElements( zeroInitialPosition, localPlayer )
            attachElements( zeroInitialPosition, vehicleVar, -0.34, 0.5, 0.82 )
            setCameraTarget( zeroInitialPosition )
        else
            detachElements( zeroInitialPosition, vehicleVar )
            attachElements( zeroInitialPosition, localPlayer, 0, -0.3, 0.65 )
        end
        if getPedControlState ( localPlayer, "aim_weapon" ) then
        end
    end
end
addEventHandler ( "onClientPreRender", root, cameraFPS )
function locationSet( guix1, guiy1, guix2, guiy2, x2, y2, z2 )
    if not isCursorShowing() and not isChatBoxInputActive() and not isMainMenuActive() and boolFPS then
        local x1, y1, z1 = getElementPosition( zeroInitialPosition )
        setPedRotation( localPlayer, findRotation ( x1, y1, x2, y2 ) )
        setCameraMatrix( x1, y1, z1, x2, y2, z2, 0, 100 )
    end
end
addEventHandler ( "onClientCursorMove", root, locationSet )
function bindAim( k, state )
    if state == "down" then
        mouse1Pressed = true
    else
        mouse1Pressed = false
    end
end
bindKey ( "mouse1", "both", bindAim )
function resetControls ( )
    if boolFPS then
        setElementAlpha ( localPlayer, 0 )
        toggleControl ( "aim_weapon", boolFPS )
        toggleControl ( "backwards", boolFPS )
        toggleControl ( "sprint", boolFPS )
        toggleControl ( "right", boolFPS )
        toggleControl ( "left", boolFPS )
        toggleControl ( "fire", boolFPS )
        toggleControl ( "enter_vehicle", boolFPS )
        toggleControl ( "enter_passenger", boolFPS )
    else
        setElementAlpha ( localPlayer, 255 )
        toggleControl ( "aim_weapon", not boolFPS )
        toggleControl ( "backwards", not boolFPS )
        toggleControl ( "sprint", not boolFPS )
        toggleControl ( "right", not boolFPS )
        toggleControl ( "left", not boolFPS )
        toggleControl ( "fire", not boolFPS )
        toggleControl ( "enter_vehicle", not boolFPS )
        toggleControl ( "enter_passenger", not boolFPS )
    end
end
function drawCrosshair()
    crossDraw = not crossDraw
    if crossDraw then
        if boolFPS then
            crosshairTimerSet = setTimer( function() dxDrawImage ( ( sw / 2 ) - 4, ( sh / 2 ) - 4, 32, 32, "crosshair.png" ) end, 1, 0 )
        end
    else
        killTimer( crosshairTimerSet )
    end
end
bindKey( "num_5", "down", drawCrosshair )
cameraCount = 0
function toggleFPS()
    cameraCount = cameraCount+1
    if cameraCount == 3 then
        boolFPS = true
        if boolFPS then
            cameraFPS()
        end
    elseif cameraCount > 3 then
        cameraCount = 0
        boolFPS = false
    end
    if not boolFPS then
        setCameraTarget ( localPlayer )
    end
    resetControls()
end
bindKey( "v", "down", toggleFPS )