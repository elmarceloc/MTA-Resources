local WORKING_DIMENSION = 200

function getWorkingDimension()
	return WORKING_DIMENSION
end
